﻿namespace CP3.MVC.Application.Dtos
{
    public class BarcoEditDto : BarcoDto
    {
    }
}
