using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CP3.MVC.Views.Barco
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
